//
//  Haneke.h
//  Haneke
//
//  Created by Luis Ascorbe on 23/07/14.
//  Copyright (c) 2014 Haneke. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Haneke.
FOUNDATION_EXPORT double HanekeVersionNumber;

//! Project version string for Haneke.
FOUNDATION_EXPORT const unsigned char HanekeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Haneke/PublicHeader.h>


